# TradePilot

TradePilot is a professional trading-terminal starter with:

- Twelve Data-backed real market charts
- Server-side API key protection
- Multiple instruments and timeframes
- Manual account balance/equity/P&L/risk inputs
- Explainable confluence UI
- Market-structure/liquidity/POI/FVG analysis UI foundation
- Responsive terminal layout
- Demo/manual account separation

## Important data architecture

Market prices come from Twelve Data through the server. The Twelve Data key is NEVER placed in browser JavaScript.

Account balance, equity, P/L, and risk are MANUAL. TradePilot does not read these from a broker.

## Run

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Put your Twelve Data API key in `TWELVE_DATA_API_KEY`.
4. Run:

```bash
npm install
npm start
```

5. Open:

http://localhost:3000

## Twelve Data notes

Twelve Data provides time-series OHLC data and real-time quote streaming/API access depending on plan and market coverage. API/WebSocket quotas and display/licensing rights depend on the selected plan. Check your Twelve Data account before deploying a public commercial data display.

## Manual account

The dashboard deliberately does NOT connect balance/equity/P&L to Exness, MT5, or another broker.

Use the Manual Account panel to enter:

- Balance
- Equity
- Today's P/L
- Risk % per trade

These values are stored locally in the browser in this starter.

## Production next steps

- Add authentication and PostgreSQL
- Persist manual account settings server-side
- Implement full MarketStructureEngine
- Implement LiquidityEngine
- Implement POI/FVG/PriceAction engines
- Implement real ConfluenceEngine calculations from OHLC data
- Add journal/backtester/alerts/calendar persistence
- Add Twelve Data WebSocket for supported real-time streams
- Add server-side caching/rate-limit handling
- Add production security, logging, testing, and deployment
