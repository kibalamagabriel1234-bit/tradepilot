
import express from "express";
import dotenv from "dotenv";
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const KEY = process.env.TWELVE_DATA_API_KEY;
const BASE = "https://api.twelvedata.com";
const allowed = new Set(["1min","3min","5min","15min","30min","1h","2h","4h","1day","1week","1month"]);

app.use(express.json({limit:"1mb"}));
app.use(express.static("public"));

function fail(res, msg, code=400){ return res.status(code).json({status:"error", message:msg}); }

async function td(path, params={}) {
  if(!KEY) throw new Error("Twelve Data API key is not configured.");
  const u = new URL(BASE + path);
  Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,v));
  u.searchParams.set("apikey", KEY);
  const r = await fetch(u);
  const data = await r.json();
  if(!r.ok || data.status==="error") throw new Error(data.message || `Twelve Data HTTP ${r.status}`);
  return data;
}

app.get("/api/health", (_req,res)=>res.json({ok:true, provider:"Twelve Data", configured:Boolean(KEY)}));

app.get("/api/series", async (req,res)=>{
  try{
    const symbol=String(req.query.symbol||"EUR/USD").trim();
    const interval=String(req.query.interval||"15min");
    const outputsize=Math.min(Math.max(Number(req.query.outputsize||500),50),5000);
    if(!allowed.has(interval)) return fail(res,"Unsupported interval.");
    const data=await td("/time_series",{symbol,interval,outputsize,format:"JSON"});
    res.json(data);
  }catch(e){ fail(res,e.message,500); }
});

app.get("/api/quote", async (req,res)=>{
  try{
    const symbol=String(req.query.symbol||"EUR/USD").trim();
    res.json(await td("/quote",{symbol}));
  }catch(e){ fail(res,e.message,500); }
});

app.get("/api/price", async (req,res)=>{
  try{
    const symbol=String(req.query.symbol||"EUR/USD").trim();
    res.json(await td("/price",{symbol}));
  }catch(e){ fail(res,e.message,500); }
});

app.use((req,res)=>res.sendFile(process.cwd()+"/public/index.html"));
app.listen(PORT,()=>console.log(`TradePilot running on http://localhost:${PORT}`));
