const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.TWELVE_DATA_API_KEY;

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const allowedIntervals = new Set([
  "1min","3min","5min","15min","30min","1h","2h","4h","1day","1week","1month"
]);

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, provider: "Twelve Data", configured: Boolean(API_KEY) });
});

app.get("/api/series", async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: "Twelve Data API key is not configured." });

    const symbol = String(req.query.symbol || "XAU/USD");
    const interval = String(req.query.interval || "15min");
    const outputsize = Math.min(Math.max(Number(req.query.outputsize || 250), 20), 5000);

    if (!allowedIntervals.has(interval)) {
      return res.status(400).json({ error: "Unsupported interval." });
    }

    const url = new URL("https://api.twelvedata.com/time_series");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("interval", interval);
    url.searchParams.set("outputsize", String(outputsize));
    url.searchParams.set("apikey", API_KEY);
    url.searchParams.set("format", "JSON");

    const r = await fetch(url);
    const data = await r.json();

    if (!r.ok || data.status === "error") {
      return res.status(r.status || 502).json({ error: data.message || "Twelve Data request failed." });
    }

    const values = (data.values || []).reverse().map(c => ({
      time: Math.floor(new Date(c.datetime).getTime() / 1000),
      datetime: c.datetime,
      open: Number(c.open),
      high: Number(c.high),
      low: Number(c.low),
      close: Number(c.close),
      volume: c.volume == null ? null : Number(c.volume)
    }));

    res.json({
      meta: data.meta || {},
      values,
      provider: "Twelve Data",
      demo: false,
      fetchedAt: new Date().toISOString()
    });
  } catch (e) {
    res.status(500).json({ error: e.message || "Server error." });
  }
});

app.get("/api/quote", async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: "Twelve Data API key is not configured." });
    const symbol = String(req.query.symbol || "XAU/USD");

    const url = new URL("https://api.twelvedata.com/quote");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("apikey", API_KEY);

    const r = await fetch(url);
    const data = await r.json();
    if (!r.ok || data.status === "error") {
      return res.status(r.status || 502).json({ error: data.message || "Quote request failed." });
    }
    res.json({ ...data, provider: "Twelve Data", demo: false, fetchedAt: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ error: e.message || "Server error." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`TradePilot running at http://localhost:${PORT}`);
});
